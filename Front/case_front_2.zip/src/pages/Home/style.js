import styled from 'styled-components';

export const MyBody = styled.body`
    margin: 0;
    padding: 0;
    margin-top: 1vw;
    text-align: center;
    `;