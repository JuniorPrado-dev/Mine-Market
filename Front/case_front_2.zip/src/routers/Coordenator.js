export const goToHome=(navigate)=>{
    navigate(`/`)
}
export const goToEndOrder=(navigate)=>{
    navigate(`/end-order`)
}
export const goToBack=(navigate)=>{
    navigate("-1")
}
